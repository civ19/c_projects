#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>


char board[3][3];
bool running = false;
const char p1 = 'X';
const char p2 = 'O';
int player;
int freespaces;
int x;
int y;
char winner = ' ';
char pwin;
bool on;

void resetboard() { //make a board of empty spaces

  for(int i=0; i<3; i++) {
    for(int n=0; n<3; n++) {
      board[i][n] = ' ';
    }
  }
  
} 

int check_fs() {
  freespaces = 9;

  for(int i=0; i<3; i++) {
    for(int n=0; n<3; n++) {
      if(board[i][n] != ' ') {
        freespaces--;
      }
    }
  }
  return freespaces;
  
}

void playerTurn1() {
 
  player = 1; //whether player 1 or player 2
  

  do {
    printf("\n\nPlayer 1's turn!");
    printf("\nWhat row? ");
    scanf("%d", &x);
    x--;
    printf("What column? ");
    scanf("%d", &y);
    y--;

    if(board[x][y] != ' ') {
      printf("Invalid move! Play again\n");
    }
    

    else {
      board[x][y] = p1;  
      break;
    }
    
  } while(board[x][y] != ' ' && player == 1);

  if (board[x][y] != ' ' && player == 1) {
    player = 2;
    
    
  } 
  
  
}

void playerTurn2() {
  
  player = 2;
  
  do {
    printf("\n\nPlayer 2's turn!\n");
    printf("What row? ");
    scanf("%d", &x);
    x--;
    printf("What column? ");
    scanf("%d", &y);
    y--;

    if(board[x][y] != ' ') {
      printf("Invalid move! Play again\n");
    }

    else {
      board[x][y] = p2;
      break;
    }
  } while(board[x][y] != ' ' && player == 2);
  if (board[x][y] != ' ' && player == 2) {
    player = 1;
    
  }
  
}
  


void checkwinner(char p1, char p2) {
  
  if((board[0][0] == p1) && (board[1][1] == p1) && (board[2][2] == p1)) { //diagonal 1
   // printf("P1 wins!");
    winner = '1';
    pwin = '1';
  }
  if(board[2][0] == p1 && board[1][1] == p1 && board[0][2] == p1) { //diagonal 2
  //  printf("P1 wins!\n\n"); 
    winner = '1';
    pwin = '1';
  }
  if(board[0][0] == p1 && board[0][1] == p1 && board[0][2] == p1) { //horizontal 1
  //  printf("P1 wins!\n\n"); 
    winner = '1';
    pwin = '1';
  }
  if(board[1][0] == p1 && board[1][1] == p1 && board[1][2] == p1) { //horizontal 2
 //   printf("P1 wins!\n\n"); 
    winner = '1';
    pwin = '1';
  }
  if(board[2][0] == p1 && board[2][1] == p1 && board[2][2] == p1) { //horizontal 3
 //   printf("P1 wins!\n\n"); 
    winner = '1';
    pwin = '1';
  }
  if(board[0][0] == p1 && board[1][0] == p1 && board[2][0] == p1) { //vertical 1
  //  printf("P1 wins!\n\n"); 
    winner = '1';
    pwin = '1';
  }
  if(board[0][1] == p1 && board[1][1] == p1 && board[2][1] == p1) { //vertical 2
 //   printf("P1 wins!\n\n"); 
    winner = '1';
    pwin = '1';
  }
  if(board[0][2] == p1 && board[1][2] == p1 && board[2][2] == p1) { //vertical 3
  //  printf("P1 wins!\n\n"); 
    winner = '1';
    pwin = '1';
  }
  
  if((board[0][0] == p2) && (board[1][1] == p2) && (board[2][2] == p2)) { //diagonal 1
    winner = '1';
    pwin = '2';
  }
  if(board[2][0] == p2 && board[1][1] == p2 && board[0][2] == p2) { //diagonal 2
    winner = '1';
    pwin = '2';
    }
  if(board[0][0] == p2 && board[0][1] == p2 && board[0][2] == p2) { //horizontal 1 
      winner = '1';
      pwin = '2';
  }
  if(board[1][0] == p2 && board[1][1] == p2 && board[1][2] == p2) { //horizontal 2
    winner = '1';
    pwin = '2';
  }
  if(board[2][0] == p2 && board[2][1] == p2 && board[2][2] == p2) { //horizontal 3
    winner = '1';
    pwin = '2';
  }
  if(board[0][0] == p2 && board[1][0] == p2 && board[2][0] == p2) { //vertical 1
    winner = '1';
    pwin = '2';
  }
  if(board[0][1] == p2 && board[1][1] == p2 && board[2][1] == p2) { //vertical 2   
    winner = '1';
    pwin = '2';
  }
}
void game() {

  printf("_%c_|_%c_|_%c_\n", board[0][0],board[0][1],board[0][2]);
  printf("_%c_|_%c_|_%c_\n", board[1][0],board[1][1],board[1][2]);
  printf(" %c | %c | %c ", board[2][0],board[2][1],board[2][2]);
}

int main (void) {
  player = 1;
  winner = '3';
  char start;
  char choice;

  printf("Welcome to Tic-Tac-Toe!\nPress Enter to start: ");
  start = getchar();
  if(start == '\n') {
    winner = ' ';
    printf("\n");
  }
  
  
  resetboard();

  while(winner == ' ' && freespaces == 0) {

    if(player == 1) {
      game();
      playerTurn1();
      
    }
    else if(player == 2) {
      game();
      playerTurn2();
    }
    checkwinner(p1,p2);

    if(winner != ' ') {
      printf("");
      game();
      printf("\n\nPlayer %c wins!\n", pwin);
  
    }
  }

  
    

}
